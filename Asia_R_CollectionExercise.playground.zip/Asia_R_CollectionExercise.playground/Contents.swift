import UIKit

var CollectedItems = ["phone Cases", "headbands", "stickers", "washi Tapes", "markers", "stationery", "nail Polish", "blankets", "stuffed animals", "cleaning supplies"]

//My array list of items

var AlphabeticalItems = CollectedItems.sorted(by:<)

//Sorts the items alphabetically and stores it in a var

for item in AlphabeticalItems {print("I collect " + item + "!")}

//takes the items from the sorted var and prints them from least to greatest in order
